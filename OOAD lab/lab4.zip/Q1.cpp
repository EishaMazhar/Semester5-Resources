#include<iostream>
using namespace std;
class application_Detail{
	protected:
	int id;
	string name;
	int tofail_score;
	int gre_score;
	float gpa;
	bool fees_status;
	
public:
		application_Detail(int id1,string name1,int score1,int score2, float gp ,bool fees){
		id=id1;
		name=name1;
			tofail_score=score1;
			gre_score=score2;
			gpa=gp;
			fees_status=fees;
		}
		void set_name(string name1){
			name=name1;
		}
		void set_tofail(int score1){
			tofail_score=score1;
		}
		
		void set_gre(int score2){
					gre_score=score2;
		}
          void set_gpa(float gp){
					gpa=gp;
		}		
		string get_name(){
			return name;
			
		}
			int get_tofail(){
			return tofail_score;
			
		}
			int get_gre(){
			return	gre_score;
			
		}
		
		bool check_fee(){
			if(fees_status==true)
			return true;
			else
			return false;
			
		}
		
		void display(){
			cout<<"Name :- "<<name;
			cout<<"ID :- "<<id;
				cout<<"TOFAIL Score :- "<<tofail_score;
				cout<<"GRE Score :- "<<gre_score;
				if(fees_status==true){
					cout<<"Fees paid";}
					else{
						cout<<"Fees not paid";
					}
				}
		
	
};
class zaki_sahib{
	protected:
	bool fees_mark;
	application_Detail *detail;
	public:
		zaki_sahib(application_Detail *a):detail(a){
			
		}
		void set_mark(){
			if(detail->check_fee()==true)
			fees_mark==true;
			else
			fees_mark==false;
		}
		bool check(){
			if(fees_mark==true){
				return true;
			}
			else{
				return false;
			}
		}
};
class abdul_saeed{
	public:
		application_Detail det;
		
		
	
};
class atif_tahir{
	protected:
		application_Detail *detail;
		zaki_sahib *sahib;
		int i;
		public:
			atif_tahir(application_Detail *ap, zaki_sahib *za):detail(ap),sahib(za){
				i=0;
			}
			void view(){
				int score1,score2;
				bool fees;
				score1=detail->get_gre();
				score2=detail->get_tofail();
				if(score1>60 && score2>60 && fees==true){
					i++;
				}
				if(i>0){
					detail->display();
				}
				
			}
			
			
	
};
class mazoor_sahib{
	protected:
		application_Detail *detail;
		public:
			mazoor_sahib(application_Detail *ap):detail(ap){
			}
			void view_status(){
				detail->display();
			}
};
class employee{
	protected:
		string name;
		string username;
		string password;
		int jobs;
		public:
			void set_name(string name1){
				name=name1;
				}
				void set_user_name(string username1){
				username=username1;
				}
				void set_pass(string pass){
				password=pass;
				}
				void set_jobs(int jobs1){
					jobs=jobs1;
				}
				string set_name(){
				return name;
				}
				string set_user_name( ){
				return username;
				}
				
				int set_jobs(){
					return jobs;
				}
				
				
};
class administrator{
	protected:
	employee *e;
	administrator(employee *E):e(E){
		
	}
	public:
	void deactivate(){
		e->set_name("Account deactivated");
		e->set_user_name("Account deactivated");
	}
};
main(){
	application_Detail *app=new application_Detail(1,"XYZ",75,75,3.3,true);
	zaki_sahib *z=new zaki_sahib(app);
	
	  
	
}
