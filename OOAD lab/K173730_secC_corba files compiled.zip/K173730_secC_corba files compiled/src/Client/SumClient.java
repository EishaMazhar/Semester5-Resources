package client;

import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import SumApp.*;

public class SumClient {
	public static void main(String[] args) {
		try {
			ORB orb = ORB.init(args, null);
			org.omg.CORBA.Object objRef = orb
					.resolve_initial_references("NameService");
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
			SumServer ss = SumServerHelper.narrow(ncRef
					.resolve_str("SUM-SERVER"));
			int addSolution = ss.sum(92,8);
			System.out.println("92 + 8 = " + addSolution);
			System.out.println("Alhamdulilah done !");
			System.out.println("Thank you Sir Abdul Rehman s for your support !");
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
	}
}